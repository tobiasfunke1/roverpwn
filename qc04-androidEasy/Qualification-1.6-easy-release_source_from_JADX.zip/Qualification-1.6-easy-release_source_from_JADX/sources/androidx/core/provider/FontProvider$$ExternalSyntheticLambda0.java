package androidx.core.provider;

import java.util.Comparator;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class FontProvider$$ExternalSyntheticLambda0 implements Comparator {
    public final int compare(Object obj, Object obj2) {
        return FontProvider.lambda$static$0((byte[]) obj, (byte[]) obj2);
    }
}
