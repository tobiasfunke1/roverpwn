package androidx.core.view;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ViewKt$$ExternalSyntheticLambda3 implements Runnable {
    public final /* synthetic */ Function0 f$0;

    public /* synthetic */ ViewKt$$ExternalSyntheticLambda3(Function0 function0) {
        this.f$0 = function0;
    }

    public final void run() {
        ViewKt.m694postOnAnimationDelayed$lambda1(this.f$0);
    }
}
