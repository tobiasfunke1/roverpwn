package androidx.core.view.accessibility;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class AccessibilityNodeInfoCompat$$ExternalSyntheticApiModelOutline2 {
}
